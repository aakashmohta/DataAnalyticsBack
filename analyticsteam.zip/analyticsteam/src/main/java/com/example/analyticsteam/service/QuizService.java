package com.example.analyticsteam.service;

import com.example.analyticsteam.entity.DataBase;
import com.example.analyticsteam.entity.Quiz;
import com.example.analyticsteam.repository.QuizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QuizService {
    @Autowired
    QuizRepository quizRepository;
    public Quiz save(Quiz quiz){
        return quizRepository.save(quiz);
    }
}
