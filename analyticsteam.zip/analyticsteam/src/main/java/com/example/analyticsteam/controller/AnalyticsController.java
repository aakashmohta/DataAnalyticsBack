package com.example.analyticsteam.controller;

import com.example.analyticsteam.dto.QueryDTO;
import com.example.analyticsteam.entity.DataBase;
import com.example.analyticsteam.entity.Quiz;
import com.example.analyticsteam.entity.User;
import com.example.analyticsteam.service.DataBaseService;
import com.example.analyticsteam.service.QuizService;
import com.example.analyticsteam.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("analytics")
public class AnalyticsController {
    @Autowired
    UserService userService;
    @Autowired
    DataBaseService dataBaseService;
    @Autowired
    QuizService quizService;
    @Autowired
    MongoTemplate mongoTemplate;

    @GetMapping("/query")
    public void getDTO(@RequestBody QueryDTO queryDTO){
        switch (queryDTO.getChannel_id()){
            case 1://common infra
                if(queryDTO.getAction().equals("register")) {
                    User user = new User();
                    user.setUserId(queryDTO.getUserId());
                    int catUser[] = {0, 0, 0, 0, 0};
                    user.setCategories(catUser);
                    user.setPopularity(0);
                    user.setFollowersPb(0);
                    user.setFollowersQuora(0);
                    user.setViews(0);
                    userService.save(user);
                }
                break;
            case 2://pagebook
                if(queryDTO.getAction().equals("posting")){
                    DataBase dataBase=new DataBase();
                    dataBase.setCategory(queryDTO.getCategory());
                    dataBase.setPlatform("pagebook");
                    dataBase.setTime(queryDTO.getTime());
                    dataBase.setId(queryDTO.getTypeId());
                    dataBase.setComments(0);
                    dataBase.setDislikes(0);
                    dataBase.setLikes(0);
                    dataBase.setSubscribed(0);
                    dataBase.setShares(0);
                    dataBaseService.save(dataBase);

                    Query query=new Query();
                    query.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                    update.inc("category.$[0]",1);
                    else if(queryDTO.getCategory().equals("science"))
                        update.inc("category.$[1]",1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update.inc("category.$[2]",1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update.inc("category.$[3]",1);
                    else
                        update.inc("category.$[4]",1);
                    mongoTemplate.updateFirst(query,update,User.class);
                }

                else if(queryDTO.getAction().equals("like")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getTypeId()));
                    Update update=new Update();
                    update.set("likes","likes"+1);
                    mongoTemplate.updateFirst(query,update,DataBase.class);

                    Query query1=new Query();
                    query1.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update1=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                        update1.inc("category.$[0]",1);
                    else if(queryDTO.getCategory().equals("science"))
                        update1.inc("category.$[1]",1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update1.inc("category.$[2]",1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update1.inc("category.$[3]",1);
                    else
                        update1.inc("category.$[4]",1);
                    mongoTemplate.updateFirst(query1,update1,User.class);
                }

                else if(queryDTO.getAction().equals("dislike")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getTypeId()));
                    Update update=new Update();
                    update.inc("dislikes",-1);
                    mongoTemplate.updateFirst(query,update,DataBase.class);

                    Query query1=new Query();
                    query1.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update1=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                        update1.inc("category.$[0]",-1);
                    else if(queryDTO.getCategory().equals("science"))
                        update1.inc("category.$[1]",-1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update1.inc("category.$[2]",-1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update1.inc("category.$[3]",-1);
                    else
                        update1.inc("category.$[4]",-1);
                    mongoTemplate.updateFirst(query1,update1,User.class);
                }
                else if(queryDTO.getAction().equals("comment")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getTypeId()));
                    Update update=new Update();
                    update.inc("comments",1);
                    mongoTemplate.updateFirst(query,update,DataBase.class);

                    Query query1=new Query();
                    query1.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update1=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                        update1.inc("category.$[0]",1);
                    else if(queryDTO.getCategory().equals("science"))
                        update1.inc("category.$[1]",1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update1.inc("category.$[2]",1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update1.inc("category.$[3]",1);
                    else
                        update1.inc("category.$[4]",1);
                    mongoTemplate.updateFirst(query1,update1,User.class);
                }

                else if(queryDTO.getAction().equals("share")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getTypeId()));
                    Update update=new Update();
                    update.inc("shares",1);
                    mongoTemplate.updateFirst(query,update,DataBase.class);

                    Query query1=new Query();
                    query1.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update1=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                        update1.inc("category.$[0]",1);
                    else if(queryDTO.getCategory().equals("science"))
                        update1.inc("category.$[1]",1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update1.inc("category.$[2]",1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update1.inc("category.$[3]",1);
                    else
                        update1.inc("category.$[4]",1);
                    mongoTemplate.updateFirst(query1,update1,User.class);
                }

                else if(queryDTO.getAction().equals("view profile")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getUserId()));
                    Update update=new Update();
                    update.inc("views",1);
                    mongoTemplate.updateFirst(query,update,User.class);
                }
                break;

            case 3://quora
                if(queryDTO.getAction().equals("posting")){
                    DataBase dataBase=new DataBase();
                    dataBase.setCategory(queryDTO.getCategory());
                    dataBase.setPlatform("quora");
                    dataBase.setTime(queryDTO.getTime());
                    dataBase.setId(queryDTO.getTypeId());
                    dataBase.setComments(0);
                    dataBase.setDislikes(0);
                    dataBase.setLikes(0);
                    dataBase.setSubscribed(0);
                    dataBase.setShares(0);
                    dataBaseService.save(dataBase);

                    Query query=new Query();
                    query.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                        update.set("category.$[0]","category.$[0]"+1);
                    else if(queryDTO.getCategory().equals("science"))
                        update.inc("category.$[1]",1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update.inc("category.$[2]",1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update.inc("category.$[3]",1);
                    else
                        update.inc("category.$[4]",1);
                    mongoTemplate.updateFirst(query,update,User.class);
                }

                else if(queryDTO.getAction().equals("view profile")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getUserId()));
                    Update update=new Update();
                    update.inc("views",1);
                    mongoTemplate.updateFirst(query,update,User.class);
                }

                else if(queryDTO.getAction().equals("comment")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getTypeId()));
                    Update update=new Update();
                    update.inc("comments",1);
                    mongoTemplate.updateFirst(query,update,DataBase.class);

                    Query query1=new Query();
                    query1.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update1=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                        update1.inc("category.$[0]",1);
                    else if(queryDTO.getCategory().equals("science"))
                        update1.inc("category.$[1]",1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update1.inc("category.$[2]",1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update1.inc("category.$[3]",1);
                    else
                        update1.inc("category.$[4]",1);
                    mongoTemplate.updateFirst(query1,update1,User.class);
                }

                else if(queryDTO.getAction().equals("dislike")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getTypeId()));
                    Update update=new Update();
                    update.inc("dislikes",-1);
                    mongoTemplate.updateFirst(query,update,DataBase.class);

                    Query query1=new Query();
                    query1.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update1=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                        update1.inc("category.$[0]",-1);
                    else if(queryDTO.getCategory().equals("science"))
                        update1.inc("category.$[1]",-1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update1.inc("category.$[2]",-1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update1.inc("category.$[3]",-1);
                    else
                        update1.inc("category.$[4]",-1);
                    mongoTemplate.updateFirst(query1,update1,User.class);
                }

                else if(queryDTO.getAction().equals("like")){
                    Query query=new Query();
                    query.addCriteria(Criteria.where("id").is(queryDTO.getTypeId()));
                    Update update=new Update();
                    update.inc("likes",1);
                    mongoTemplate.updateFirst(query,update,DataBase.class);

                    Query query1=new Query();
                    query1.addCriteria(Criteria.where("userId").is(queryDTO.getUserId()));
                    Update update1=new Update();
                    if(queryDTO.getCategory().equals("technology"))
                        update1.inc("category.$[0]",1);
                    else if(queryDTO.getCategory().equals("science"))
                        update1.inc("category.$[1]",1);
                    else if(queryDTO.getCategory().equals("bollywood"))
                        update1.inc("category.$[2]",1);
                    else if(queryDTO.getCategory().equals("sports"))
                        update1.inc("category.$[3]",1);
                    else
                        update1.inc("category.$[4]",1);
                    mongoTemplate.updateFirst(query1,update1,User.class);
                }
                break;

            case 4://quiz
                Quiz quiz=new Quiz();
                quiz.setQuizId(queryDTO.getTypeId());
                quiz.setWinnerId(queryDTO.getWinnerId());
                quiz.setUsersRegistered(queryDTO.getUsersRegistered());
                quiz.setMostAnsQ(queryDTO.getMostAnsQ());
                quiz.setStartTime(queryDTO.getTime());
                quizService.save(quiz);
                break;
        }
    }


    @PostMapping("/get")
    public void getData(int getData, LocalDateTime date1){

        switch (getData){
            case 1:

        }
    }
}
