package com.example.analyticsteam.service;

import com.example.analyticsteam.entity.DataBase;
import com.example.analyticsteam.entity.GraphList;
import com.example.analyticsteam.repository.DataBaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;

@Service
public class DataBaseService {
    @Autowired
    DataBaseRepository dataBaseRepository;

    @Autowired
    MongoTemplate mongoTemplate;

    public DataBase save(DataBase dataBase){
        return dataBaseRepository.save(dataBase);
    }

    public DataBase findById(String id){
        return dataBaseRepository.findById(id).get();
    }

    public  List<GraphList> findByPageViews(){
        Query query=new Query(Criteria.where("type").is("profile"));
        List<GraphList> graphLists=new ArrayList<>();
        List<DataBase> iterable=mongoTemplate.find(query,DataBase.class);
        for (DataBase database:iterable)
        {
            graphLists.add(new GraphList(database.getId(),database.getViews()));
        }
        return graphLists;
    }

    public List<GraphList> findByPbPostLikes(){
        Query query=new Query(Criteria.where("type").is("post"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getLikes()));
        }
        return graphList;
    }

    public List<GraphList> findByPbPostDisLikes(){
        Query query=new Query(Criteria.where("type").is("post"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getDislikes()));
        }
        return graphList;
    }


    public List<GraphList> findByImageLikes(){
        Query query=new Query(Criteria.where("type").is("image"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getLikes()));
        }
        return graphList;
    }

    public List<GraphList> findByImageDisLikes(){
        Query query=new Query(Criteria.where("type").is("image"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getDislikes()));
        }
        return graphList;
    }

    public List<GraphList> findByVideoLikes(){
        Query query=new Query(Criteria.where("type").is("video"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getLikes()));
        }
        return graphList;
    }

    public List<GraphList> findByVideoDisLikes(){
        Query query=new Query(Criteria.where("type").is("video"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getDislikes()));
        }
        return graphList;
    }

    public List<GraphList> findByQuoraComments(){
        Query query=new Query(Criteria.where("type").is("quorapost"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getComments()));
        }
        return graphList;
    }

    public List<GraphList> findByQuoraLikes(){
        Query query=new Query(Criteria.where("type").is("quorapost"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getLikes()));
        }
        return graphList;
    }

    public List<GraphList> findByQuoraDislikes(){
        Query query=new Query(Criteria.where("type").is("quorapost"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getDislikes()));
        }
        return graphList;
    }


    public List<GraphList> findByPopularQuoraPost(){
        Query query=new Query().addCriteria(Criteria.where("type").is("quoraPost")).with(Sort.by(Sort.Direction.DESC,"comments"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getComments()));
        }
        return graphList;
    }


    public List<GraphList> findByPopularImage(){
        Query query=new Query().addCriteria(Criteria.where("type").is("image")).with(Sort.by(Sort.Direction.DESC,"likes"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getLikes()));
        }
        return graphList;
    }

    public List<GraphList> findByPopularVideo(){
        Query query=new Query().addCriteria(Criteria.where("type").is("video")).with(Sort.by(Sort.Direction.DESC,"likes"));
        List<GraphList> graphList=new ArrayList<>();
        List<DataBase> dataBaseList=mongoTemplate.find(query,DataBase.class);
        for(DataBase dataBase:dataBaseList){
            graphList.add(new GraphList(dataBase.getId(),dataBase.getLikes()));
        }
        return graphList;
    }

}
