package com.example.analyticsteam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnalyticsteamApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnalyticsteamApplication.class, args);
	}

}
