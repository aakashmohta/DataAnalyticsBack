package com.example.analyticsteam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalyticsteamApplicationTests {

	@Test
	void contextLoads() {
	}

}
